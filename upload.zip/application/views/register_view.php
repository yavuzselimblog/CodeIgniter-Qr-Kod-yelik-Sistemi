<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>qr kodlu üye girişi</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<body>

<div class="mb-5"></div>
<div id="container text-center" align="center">

<div class="card col-md-6 text-center">
	<div class="card-header"><h1>qr kodlu üye girişi</h1></div>
	<div class="card-body">

	
		<form action="<?php echo base_url('register/registerdata');?>" method="POST">
		<input class="form-control" type="text" name="kadi" placeholder="Kullanıcı adı" /><br>
		<input class="form-control" type="text" name="eposta" placeholder="E-posta" /><br>
		<input class="form-control" type="password" name="sifre" placeholder="Şifre" /><br>
		

	</div>
	<div class="card-footer">
		<button class="btn btn-success" type="submit">Kayıt Ol</button>
		<a class="btn btn-primary" href="<?php echo base_url('login');?>">Qr kod ile üye girişi yap</a>

		</form>
	</div>
</div>


</div>

</body>
</html>