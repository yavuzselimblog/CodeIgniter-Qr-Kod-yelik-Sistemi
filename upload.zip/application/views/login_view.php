<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>qr kodlu üye girişi</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>




<div class="mb-5"></div>
<div id="container text-center" align="center">

  <div class="card col-md-6 text-center">
    <div class="card-header"><h1>qr kodlu üye girişi</h1></div>
    <div class="card-body">
      <div style="width: 300px" id="qr-reader"></div>
    </div>
    <div class="card-footer">
      <a class="btn btn-primary" href="<?php echo base_url('register');?>">Ana Sayfa</a>
    </div>
  </div>

</div>

<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
<script src="<?php echo base_url('assets/html5-qrcode.min.js');?>"></script>

<script>
const html5QrCode = new Html5Qrcode("qr-reader");
Html5Qrcode.getCameras().then(devices => {

	var cameraId = devices[0].id;  
	html5QrCode.start(
	cameraId,   
  {
    fps: 10,    
    qrbox: 300  
               
  },
  qrCodeMessage => {
	window.location.href = "<?php echo base_url('login/logindata/');?>" + qrCodeMessage;
  },
  errorMessage => {
    
  });

});
</script>

</body>
</html>