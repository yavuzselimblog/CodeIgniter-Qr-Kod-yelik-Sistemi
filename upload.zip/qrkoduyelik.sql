-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 01 Kas 2024, 19:50:15
-- Sunucu sürümü: 10.4.27-MariaDB
-- PHP Sürümü: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `qrkoduyelik`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

CREATE TABLE `uyeler` (
  `id` int(11) NOT NULL,
  `kadi` varchar(500) NOT NULL,
  `eposta` varchar(500) NOT NULL,
  `sifre` varchar(500) NOT NULL,
  `qrkodresim` varchar(1000) NOT NULL,
  `qrkodkripto` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`id`, `kadi`, `eposta`, `sifre`, `qrkodresim`, `qrkodkripto`) VALUES
(6, 'selimsahin', 'selimsahin@w.cn', 'adcd7048512e64b48da55b027577886ee5a36350', 'eeed3949089f8a732c10f39329f637d9f5dc1e1e672520c6c3b64.png', 'eeed3949089f8a732c10f39329f637d9f5dc1e1e672520c6c3b64'),
(5, 'selim', 'selim@w.cn', 'adcd7048512e64b48da55b027577886ee5a36350', '073a50efa9176bad855b190ef8864b14b26a4be76725201b53033.png', '073a50efa9176bad855b190ef8864b14b26a4be76725201b53033'),
(4, 'yav', 'softwarencoder@yavuz-selim.com', 'adcd7048512e64b48da55b027577886ee5a36350', 'ccee03602e698bf434c4f9312a8c4ed2c884a7b167251f753ca7a.png', 'ccee03602e698bf434c4f9312a8c4ed2c884a7b167251f753ca7a'),
(7, 'selimsahin', 'selimsahin', 'fe703d258c7ef5f50b71e06565a65aa07194907f', '28da4b92e611c72a4094baa0b7601fc0d9f2c44e672521306cf53.png', '28da4b92e611c72a4094baa0b7601fc0d9f2c44e672521306cf53');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `uyeler`
--
ALTER TABLE `uyeler`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `uyeler`
--
ALTER TABLE `uyeler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
