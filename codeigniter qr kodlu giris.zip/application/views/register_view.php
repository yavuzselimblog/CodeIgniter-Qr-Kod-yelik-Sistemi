<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>qr kodlu üye girişi</title>

</head>
<body>

<div id="container">
	<h1>qr kodlu üye girişi</h1>

	<form action="<?php echo base_url('register/registerdata');?>" method="POST">
	<input type="text" name="kadi" placeholder="Kullanıcı adı" /><br>
	<input type="text" name="eposta" placeholder="E-posta" /><br>
	<input type="password" name="sifre" placeholder="Şifre" /><br>
	<button type="submit">Kayıt Ol</button>
	<a href="<?php echo base_url('login');?>">Qr kod ile üye girişi yap</a>

	</form>

</div>

</body>
</html>