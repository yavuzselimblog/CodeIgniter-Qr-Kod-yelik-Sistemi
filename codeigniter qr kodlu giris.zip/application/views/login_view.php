<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>qr kodlu üye girişi</title>

</head>
<body>

<div id="container">
	<h1>qr kodlu üye girişi</h1>
	<div style="width: 300px" id="qr-reader"></div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
<script src="<?php echo base_url('assets/html5-qrcode.min.js');?>"></script>

<script>
const html5QrCode = new Html5Qrcode("qr-reader");
Html5Qrcode.getCameras().then(devices => {

	var cameraId = devices[0].id;  
	html5QrCode.start(
	cameraId,   
  {
    fps: 10,    
    qrbox: 300  
               
  },
  qrCodeMessage => {
	window.location.href = "<?php echo base_url('login/logindata/');?>" + qrCodeMessage;
  },
  errorMessage => {
    console.log("Hata oluştu");
  });

});
</script>

</body>
</html>